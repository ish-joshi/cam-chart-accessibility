from gpapi.googleplay import GooglePlayAPI

# https://github.com/krnick/GooglePlay-API
mail = None
passwd = None
# The gsfId and authSubToken are retrieved from the mail and passwd.
# call api.gsfId and api.authSubToken
gsfId = 4132308869485558804
authSubToken = '0gc-qsIOLGFubtuKlPD9UE-24mcMCanGWWFBFLBF1fiCjNdIAPmFoQDBfQKNDHYJSAesxw.'

api = GooglePlayAPI(locale="en_US", timezone="UTC", device_codename="hero2lte")
# api.login(email=mail, password=passwd) # do this the first time!!!
api.login(gsfId=gsfId, authSubToken=authSubToken)


def searchApps(query):
    search_res = api.search(query)
    # region search results print
    apps = []
    for doc in search_res:
        if 'docid' in doc:
            print("doc: {}".format(doc["docid"]))
        for cluster in doc["child"]:
            print("\tcluster: {}".format(cluster["docid"]))
            for app in cluster["child"]:
                apps.append(app)
    return apps
    # endregion


result = searchApps("bitcoin")
print(result)

suggestions = api.searchSuggest("face")
print(suggestions)


def downloadAndSave(package, filepath=None):
    if not filepath:
        filepath = "out/{}.apk".format(package)
    # region download and write apk
    apk_bits = api.download(package)
    with open(filepath, 'wb') as o:
        for chunk in apk_bits.get('file')['data']:
            o.write(chunk)

    # endregion


to_download = "com.gamma.scan"
downloadAndSave(to_download)
